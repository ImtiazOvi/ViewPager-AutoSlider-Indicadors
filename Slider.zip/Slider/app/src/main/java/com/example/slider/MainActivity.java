package com.example.slider;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;
import android.text.Html;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    ViewPager viewPager;
    LinearLayout dotslayout_id;
    TextView[] mDots;
    SliderAdapter sliderAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        viewPager = findViewById(R.id.viewPager_id);
        dotslayout_id = findViewById(R.id.dotslayout_id);
        sliderAdapter = new SliderAdapter(this);

        viewPager.setAdapter(sliderAdapter);
        addDotsIndicator();

    }

    public void addDotsIndicator(){
        mDots = new TextView[3];
        for (int i = 0 ; i< mDots.length; i++){
            mDots[i] = new TextView(this);
            //mDots[i].setText(Html.fromHtml("&#8226;"));
            mDots[i].setTextSize(35);
            dotslayout_id.addView(mDots[i]);
        }
    }

}
